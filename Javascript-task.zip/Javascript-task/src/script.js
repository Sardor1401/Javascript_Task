const form = document.getElementById("form");
const input = document.getElementById("input");
const submit = document.getElementById("submit");
const tasks = document.getElementById("tasks");

const todos = [

]



form.onsubmit = function (event) {
    event.preventDefault();
    const taskItem = input.value;

    const todo = {
        id: todos.length,
        title: taskItem,
    }

    todos.push(todo)
    updateUI()


    form.reset();
}


function updateUI() {
    tasks.innerHTML = ""
    todos.forEach(todo => {
        tasks.innerHTML += ` <div class="flex justify-between items-center mt-4">
        <ul class="list-disc list-inside">
            <li id ="title-${todo.id}">${todo.title}</li>
            <input id='input-${todo.id}' class="hidden"/>
            <button id="submit-button-${todo.id}" onclick = "tugmaEdit(${todo.id})" class="border p-2 hidden rounded-md bg-[#0000FF] text-white"  id = "inputIcon">&#10003;</button>
        </ul>
        <div>
            <button class="border bg-[#FF1493] text-slate-100 rounded-md p-[5px] text-center"
                type="button" onclick="editTodo(${todo.id})">Edit</button>
            <button class="border bg-[#DC143C] text-white p-[5px] rounded-md text-center"
                type="button" onclick="deleteTodo(event)">Delete</button>
        </div>
    </div>`
    })
}



function editTodo(id) {
    const input = document.getElementById(`input-${id}`);
    input.classList.remove('hidden');
    const button = document.getElementById(`submit-button-${id}`);
    button.classList.remove('hidden');
    const title = document.getElementById(`title-${id}`);
    title.classList.add('hidden');
    input.value = title.innerText;
}

function tugmaEdit(id) {
    const input = document.getElementById(`input-${id}`);
    const button = document.getElementById(`submit-button-${id}`);
    button.classList.add('hidden');
    todos.forEach(todo => {
        if (todo.id === id) {
            todo.title = input.value
        }
    })
    updateUI()
}


function deleteTodo(id) {
    if(todo => todo.id === id){
        todos.splice(id, 1);
    }
    updateUI()
    console.log(todos);
}
